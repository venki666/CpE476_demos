/*
 * bsp_task.h
 *
 *  Created on: Mar 5, 2022
 *      Author: Administrator
 */

#ifndef BSP_TASK_H_
#define BSP_TASK_H_


void Task_Entity_LED(void);
void Task_Entity_Beep(void);
void Task_Entity_Key(void);

#endif /* BSP_TASK_H_ */
