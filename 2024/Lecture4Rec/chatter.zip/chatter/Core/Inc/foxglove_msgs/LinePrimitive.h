#ifndef _ROS_foxglove_msgs_LinePrimitive_h
#define _ROS_foxglove_msgs_LinePrimitive_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/Point.h"
#include "foxglove_msgs/Color.h"

namespace foxglove_msgs
{

  class LinePrimitive : public ros::Msg
  {
    public:
      typedef uint8_t _type_type;
      _type_type type;
      typedef geometry_msgs::Pose _pose_type;
      _pose_type pose;
      typedef double _thickness_type;
      _thickness_type thickness;
      typedef bool _scale_invariant_type;
      _scale_invariant_type scale_invariant;
      uint32_t points_length;
      typedef geometry_msgs::Point _points_type;
      _points_type st_points;
      _points_type * points;
      typedef foxglove_msgs::Color _color_type;
      _color_type color;
      uint32_t colors_length;
      typedef foxglove_msgs::Color _colors_type;
      _colors_type st_colors;
      _colors_type * colors;
      uint32_t indices_length;
      typedef uint32_t _indices_type;
      _indices_type st_indices;
      _indices_type * indices;
      enum { LINE_STRIP = 0 };
      enum { LINE_LOOP = 1 };
      enum { LINE_LIST = 2 };

    LinePrimitive():
      type(0),
      pose(),
      thickness(0),
      scale_invariant(0),
      points_length(0), st_points(), points(nullptr),
      color(),
      colors_length(0), st_colors(), colors(nullptr),
      indices_length(0), st_indices(), indices(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->type >> (8 * 0)) & 0xFF;
      offset += sizeof(this->type);
      offset += this->pose.serialize(outbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_thickness;
      u_thickness.real = this->thickness;
      *(outbuffer + offset + 0) = (u_thickness.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_thickness.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_thickness.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_thickness.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_thickness.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_thickness.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_thickness.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_thickness.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->thickness);
      union {
        bool real;
        uint8_t base;
      } u_scale_invariant;
      u_scale_invariant.real = this->scale_invariant;
      *(outbuffer + offset + 0) = (u_scale_invariant.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->scale_invariant);
      *(outbuffer + offset + 0) = (this->points_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->points_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->points_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->points_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->points_length);
      for( uint32_t i = 0; i < points_length; i++){
      offset += this->points[i].serialize(outbuffer + offset);
      }
      offset += this->color.serialize(outbuffer + offset);
      *(outbuffer + offset + 0) = (this->colors_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->colors_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->colors_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->colors_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->colors_length);
      for( uint32_t i = 0; i < colors_length; i++){
      offset += this->colors[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->indices_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->indices_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->indices_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->indices_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->indices_length);
      for( uint32_t i = 0; i < indices_length; i++){
      *(outbuffer + offset + 0) = (this->indices[i] >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->indices[i] >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->indices[i] >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->indices[i] >> (8 * 3)) & 0xFF;
      offset += sizeof(this->indices[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->type =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->type);
      offset += this->pose.deserialize(inbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_thickness;
      u_thickness.base = 0;
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->thickness = u_thickness.real;
      offset += sizeof(this->thickness);
      union {
        bool real;
        uint8_t base;
      } u_scale_invariant;
      u_scale_invariant.base = 0;
      u_scale_invariant.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->scale_invariant = u_scale_invariant.real;
      offset += sizeof(this->scale_invariant);
      uint32_t points_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->points_length);
      if(points_lengthT > points_length)
        this->points = (geometry_msgs::Point*)realloc(this->points, points_lengthT * sizeof(geometry_msgs::Point));
      points_length = points_lengthT;
      for( uint32_t i = 0; i < points_length; i++){
      offset += this->st_points.deserialize(inbuffer + offset);
        memcpy( &(this->points[i]), &(this->st_points), sizeof(geometry_msgs::Point));
      }
      offset += this->color.deserialize(inbuffer + offset);
      uint32_t colors_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      colors_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      colors_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      colors_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->colors_length);
      if(colors_lengthT > colors_length)
        this->colors = (foxglove_msgs::Color*)realloc(this->colors, colors_lengthT * sizeof(foxglove_msgs::Color));
      colors_length = colors_lengthT;
      for( uint32_t i = 0; i < colors_length; i++){
      offset += this->st_colors.deserialize(inbuffer + offset);
        memcpy( &(this->colors[i]), &(this->st_colors), sizeof(foxglove_msgs::Color));
      }
      uint32_t indices_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      indices_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      indices_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      indices_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->indices_length);
      if(indices_lengthT > indices_length)
        this->indices = (uint32_t*)realloc(this->indices, indices_lengthT * sizeof(uint32_t));
      indices_length = indices_lengthT;
      for( uint32_t i = 0; i < indices_length; i++){
      this->st_indices =  ((uint32_t) (*(inbuffer + offset)));
      this->st_indices |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->st_indices |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->st_indices |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->st_indices);
        memcpy( &(this->indices[i]), &(this->st_indices), sizeof(uint32_t));
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/LinePrimitive"; };
    virtual const char * getMD5() override { return "6c2f969386c9a9fb9365fdf2a22d851c"; };

  };

}
#endif
