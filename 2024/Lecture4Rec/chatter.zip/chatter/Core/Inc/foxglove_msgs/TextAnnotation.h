#ifndef _ROS_foxglove_msgs_TextAnnotation_h
#define _ROS_foxglove_msgs_TextAnnotation_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "ros/time.h"
#include "foxglove_msgs/Point2.h"
#include "foxglove_msgs/Color.h"

namespace foxglove_msgs
{

  class TextAnnotation : public ros::Msg
  {
    public:
      typedef ros::Time _timestamp_type;
      _timestamp_type timestamp;
      typedef foxglove_msgs::Point2 _position_type;
      _position_type position;
      typedef const char* _text_type;
      _text_type text;
      typedef double _font_size_type;
      _font_size_type font_size;
      typedef foxglove_msgs::Color _text_color_type;
      _text_color_type text_color;
      typedef foxglove_msgs::Color _background_color_type;
      _background_color_type background_color;

    TextAnnotation():
      timestamp(),
      position(),
      text(""),
      font_size(0),
      text_color(),
      background_color()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->timestamp.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.sec);
      *(outbuffer + offset + 0) = (this->timestamp.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.nsec);
      offset += this->position.serialize(outbuffer + offset);
      uint32_t length_text = strlen(this->text);
      varToArr(outbuffer + offset, length_text);
      offset += 4;
      memcpy(outbuffer + offset, this->text, length_text);
      offset += length_text;
      union {
        double real;
        uint64_t base;
      } u_font_size;
      u_font_size.real = this->font_size;
      *(outbuffer + offset + 0) = (u_font_size.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_font_size.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_font_size.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_font_size.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_font_size.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_font_size.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_font_size.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_font_size.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->font_size);
      offset += this->text_color.serialize(outbuffer + offset);
      offset += this->background_color.serialize(outbuffer + offset);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->timestamp.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.sec);
      this->timestamp.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.nsec);
      offset += this->position.deserialize(inbuffer + offset);
      uint32_t length_text;
      arrToVar(length_text, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_text; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_text-1]=0;
      this->text = (char *)(inbuffer + offset-1);
      offset += length_text;
      union {
        double real;
        uint64_t base;
      } u_font_size;
      u_font_size.base = 0;
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->font_size = u_font_size.real;
      offset += sizeof(this->font_size);
      offset += this->text_color.deserialize(inbuffer + offset);
      offset += this->background_color.deserialize(inbuffer + offset);
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/TextAnnotation"; };
    virtual const char * getMD5() override { return "c519967875038307b79bf6d8fa469b37"; };

  };

}
#endif
