#ifndef _ROS_foxglove_msgs_PointsAnnotation_h
#define _ROS_foxglove_msgs_PointsAnnotation_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "ros/time.h"
#include "foxglove_msgs/Point2.h"
#include "foxglove_msgs/Color.h"

namespace foxglove_msgs
{

  class PointsAnnotation : public ros::Msg
  {
    public:
      typedef ros::Time _timestamp_type;
      _timestamp_type timestamp;
      typedef uint8_t _type_type;
      _type_type type;
      uint32_t points_length;
      typedef foxglove_msgs::Point2 _points_type;
      _points_type st_points;
      _points_type * points;
      typedef foxglove_msgs::Color _outline_color_type;
      _outline_color_type outline_color;
      uint32_t outline_colors_length;
      typedef foxglove_msgs::Color _outline_colors_type;
      _outline_colors_type st_outline_colors;
      _outline_colors_type * outline_colors;
      typedef foxglove_msgs::Color _fill_color_type;
      _fill_color_type fill_color;
      typedef double _thickness_type;
      _thickness_type thickness;
      enum { UNKNOWN = 0 };
      enum { POINTS = 1 };
      enum { LINE_LOOP = 2 };
      enum { LINE_STRIP = 3 };
      enum { LINE_LIST = 4 };

    PointsAnnotation():
      timestamp(),
      type(0),
      points_length(0), st_points(), points(nullptr),
      outline_color(),
      outline_colors_length(0), st_outline_colors(), outline_colors(nullptr),
      fill_color(),
      thickness(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->timestamp.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.sec);
      *(outbuffer + offset + 0) = (this->timestamp.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.nsec);
      *(outbuffer + offset + 0) = (this->type >> (8 * 0)) & 0xFF;
      offset += sizeof(this->type);
      *(outbuffer + offset + 0) = (this->points_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->points_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->points_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->points_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->points_length);
      for( uint32_t i = 0; i < points_length; i++){
      offset += this->points[i].serialize(outbuffer + offset);
      }
      offset += this->outline_color.serialize(outbuffer + offset);
      *(outbuffer + offset + 0) = (this->outline_colors_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->outline_colors_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->outline_colors_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->outline_colors_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->outline_colors_length);
      for( uint32_t i = 0; i < outline_colors_length; i++){
      offset += this->outline_colors[i].serialize(outbuffer + offset);
      }
      offset += this->fill_color.serialize(outbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_thickness;
      u_thickness.real = this->thickness;
      *(outbuffer + offset + 0) = (u_thickness.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_thickness.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_thickness.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_thickness.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_thickness.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_thickness.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_thickness.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_thickness.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->thickness);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->timestamp.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.sec);
      this->timestamp.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.nsec);
      this->type =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->type);
      uint32_t points_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->points_length);
      if(points_lengthT > points_length)
        this->points = (foxglove_msgs::Point2*)realloc(this->points, points_lengthT * sizeof(foxglove_msgs::Point2));
      points_length = points_lengthT;
      for( uint32_t i = 0; i < points_length; i++){
      offset += this->st_points.deserialize(inbuffer + offset);
        memcpy( &(this->points[i]), &(this->st_points), sizeof(foxglove_msgs::Point2));
      }
      offset += this->outline_color.deserialize(inbuffer + offset);
      uint32_t outline_colors_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      outline_colors_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      outline_colors_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      outline_colors_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->outline_colors_length);
      if(outline_colors_lengthT > outline_colors_length)
        this->outline_colors = (foxglove_msgs::Color*)realloc(this->outline_colors, outline_colors_lengthT * sizeof(foxglove_msgs::Color));
      outline_colors_length = outline_colors_lengthT;
      for( uint32_t i = 0; i < outline_colors_length; i++){
      offset += this->st_outline_colors.deserialize(inbuffer + offset);
        memcpy( &(this->outline_colors[i]), &(this->st_outline_colors), sizeof(foxglove_msgs::Color));
      }
      offset += this->fill_color.deserialize(inbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_thickness;
      u_thickness.base = 0;
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->thickness = u_thickness.real;
      offset += sizeof(this->thickness);
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/PointsAnnotation"; };
    virtual const char * getMD5() override { return "df8c4c5f6b39712f6875eeb26aff0f86"; };

  };

}
#endif
