#ifndef _ROS_foxglove_msgs_GeoJSON_h
#define _ROS_foxglove_msgs_GeoJSON_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace foxglove_msgs
{

  class GeoJSON : public ros::Msg
  {
    public:
      typedef const char* _geojson_type;
      _geojson_type geojson;

    GeoJSON():
      geojson("")
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      uint32_t length_geojson = strlen(this->geojson);
      varToArr(outbuffer + offset, length_geojson);
      offset += 4;
      memcpy(outbuffer + offset, this->geojson, length_geojson);
      offset += length_geojson;
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      uint32_t length_geojson;
      arrToVar(length_geojson, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_geojson; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_geojson-1]=0;
      this->geojson = (char *)(inbuffer + offset-1);
      offset += length_geojson;
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/GeoJSON"; };
    virtual const char * getMD5() override { return "9a1e28c92be77e1b417fd6f796eed666"; };

  };

}
#endif
