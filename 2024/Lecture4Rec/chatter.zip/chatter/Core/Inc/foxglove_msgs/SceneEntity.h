#ifndef _ROS_foxglove_msgs_SceneEntity_h
#define _ROS_foxglove_msgs_SceneEntity_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "ros/time.h"
#include "ros/duration.h"
#include "foxglove_msgs/KeyValuePair.h"
#include "foxglove_msgs/ArrowPrimitive.h"
#include "foxglove_msgs/CubePrimitive.h"
#include "foxglove_msgs/SpherePrimitive.h"
#include "foxglove_msgs/CylinderPrimitive.h"
#include "foxglove_msgs/LinePrimitive.h"
#include "foxglove_msgs/TriangleListPrimitive.h"
#include "foxglove_msgs/TextPrimitive.h"
#include "foxglove_msgs/ModelPrimitive.h"

namespace foxglove_msgs
{

  class SceneEntity : public ros::Msg
  {
    public:
      typedef ros::Time _timestamp_type;
      _timestamp_type timestamp;
      typedef const char* _frame_id_type;
      _frame_id_type frame_id;
      typedef const char* _id_type;
      _id_type id;
      typedef ros::Duration _lifetime_type;
      _lifetime_type lifetime;
      typedef bool _frame_locked_type;
      _frame_locked_type frame_locked;
      uint32_t metadata_length;
      typedef foxglove_msgs::KeyValuePair _metadata_type;
      _metadata_type st_metadata;
      _metadata_type * metadata;
      uint32_t arrows_length;
      typedef foxglove_msgs::ArrowPrimitive _arrows_type;
      _arrows_type st_arrows;
      _arrows_type * arrows;
      uint32_t cubes_length;
      typedef foxglove_msgs::CubePrimitive _cubes_type;
      _cubes_type st_cubes;
      _cubes_type * cubes;
      uint32_t spheres_length;
      typedef foxglove_msgs::SpherePrimitive _spheres_type;
      _spheres_type st_spheres;
      _spheres_type * spheres;
      uint32_t cylinders_length;
      typedef foxglove_msgs::CylinderPrimitive _cylinders_type;
      _cylinders_type st_cylinders;
      _cylinders_type * cylinders;
      uint32_t lines_length;
      typedef foxglove_msgs::LinePrimitive _lines_type;
      _lines_type st_lines;
      _lines_type * lines;
      uint32_t triangles_length;
      typedef foxglove_msgs::TriangleListPrimitive _triangles_type;
      _triangles_type st_triangles;
      _triangles_type * triangles;
      uint32_t texts_length;
      typedef foxglove_msgs::TextPrimitive _texts_type;
      _texts_type st_texts;
      _texts_type * texts;
      uint32_t models_length;
      typedef foxglove_msgs::ModelPrimitive _models_type;
      _models_type st_models;
      _models_type * models;

    SceneEntity():
      timestamp(),
      frame_id(""),
      id(""),
      lifetime(),
      frame_locked(0),
      metadata_length(0), st_metadata(), metadata(nullptr),
      arrows_length(0), st_arrows(), arrows(nullptr),
      cubes_length(0), st_cubes(), cubes(nullptr),
      spheres_length(0), st_spheres(), spheres(nullptr),
      cylinders_length(0), st_cylinders(), cylinders(nullptr),
      lines_length(0), st_lines(), lines(nullptr),
      triangles_length(0), st_triangles(), triangles(nullptr),
      texts_length(0), st_texts(), texts(nullptr),
      models_length(0), st_models(), models(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->timestamp.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.sec);
      *(outbuffer + offset + 0) = (this->timestamp.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id = strlen(this->frame_id);
      varToArr(outbuffer + offset, length_frame_id);
      offset += 4;
      memcpy(outbuffer + offset, this->frame_id, length_frame_id);
      offset += length_frame_id;
      uint32_t length_id = strlen(this->id);
      varToArr(outbuffer + offset, length_id);
      offset += 4;
      memcpy(outbuffer + offset, this->id, length_id);
      offset += length_id;
      *(outbuffer + offset + 0) = (this->lifetime.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->lifetime.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->lifetime.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->lifetime.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->lifetime.sec);
      *(outbuffer + offset + 0) = (this->lifetime.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->lifetime.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->lifetime.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->lifetime.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->lifetime.nsec);
      union {
        bool real;
        uint8_t base;
      } u_frame_locked;
      u_frame_locked.real = this->frame_locked;
      *(outbuffer + offset + 0) = (u_frame_locked.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->frame_locked);
      *(outbuffer + offset + 0) = (this->metadata_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->metadata_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->metadata_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->metadata_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->metadata_length);
      for( uint32_t i = 0; i < metadata_length; i++){
      offset += this->metadata[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->arrows_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->arrows_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->arrows_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->arrows_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->arrows_length);
      for( uint32_t i = 0; i < arrows_length; i++){
      offset += this->arrows[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->cubes_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->cubes_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->cubes_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->cubes_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->cubes_length);
      for( uint32_t i = 0; i < cubes_length; i++){
      offset += this->cubes[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->spheres_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->spheres_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->spheres_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->spheres_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->spheres_length);
      for( uint32_t i = 0; i < spheres_length; i++){
      offset += this->spheres[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->cylinders_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->cylinders_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->cylinders_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->cylinders_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->cylinders_length);
      for( uint32_t i = 0; i < cylinders_length; i++){
      offset += this->cylinders[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->lines_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->lines_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->lines_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->lines_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->lines_length);
      for( uint32_t i = 0; i < lines_length; i++){
      offset += this->lines[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->triangles_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->triangles_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->triangles_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->triangles_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->triangles_length);
      for( uint32_t i = 0; i < triangles_length; i++){
      offset += this->triangles[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->texts_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->texts_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->texts_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->texts_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->texts_length);
      for( uint32_t i = 0; i < texts_length; i++){
      offset += this->texts[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->models_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->models_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->models_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->models_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->models_length);
      for( uint32_t i = 0; i < models_length; i++){
      offset += this->models[i].serialize(outbuffer + offset);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->timestamp.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.sec);
      this->timestamp.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id;
      arrToVar(length_frame_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_frame_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_frame_id-1]=0;
      this->frame_id = (char *)(inbuffer + offset-1);
      offset += length_frame_id;
      uint32_t length_id;
      arrToVar(length_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_id-1]=0;
      this->id = (char *)(inbuffer + offset-1);
      offset += length_id;
      this->lifetime.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->lifetime.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->lifetime.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->lifetime.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->lifetime.sec);
      this->lifetime.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->lifetime.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->lifetime.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->lifetime.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->lifetime.nsec);
      union {
        bool real;
        uint8_t base;
      } u_frame_locked;
      u_frame_locked.base = 0;
      u_frame_locked.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->frame_locked = u_frame_locked.real;
      offset += sizeof(this->frame_locked);
      uint32_t metadata_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      metadata_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      metadata_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      metadata_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->metadata_length);
      if(metadata_lengthT > metadata_length)
        this->metadata = (foxglove_msgs::KeyValuePair*)realloc(this->metadata, metadata_lengthT * sizeof(foxglove_msgs::KeyValuePair));
      metadata_length = metadata_lengthT;
      for( uint32_t i = 0; i < metadata_length; i++){
      offset += this->st_metadata.deserialize(inbuffer + offset);
        memcpy( &(this->metadata[i]), &(this->st_metadata), sizeof(foxglove_msgs::KeyValuePair));
      }
      uint32_t arrows_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      arrows_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      arrows_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      arrows_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->arrows_length);
      if(arrows_lengthT > arrows_length)
        this->arrows = (foxglove_msgs::ArrowPrimitive*)realloc(this->arrows, arrows_lengthT * sizeof(foxglove_msgs::ArrowPrimitive));
      arrows_length = arrows_lengthT;
      for( uint32_t i = 0; i < arrows_length; i++){
      offset += this->st_arrows.deserialize(inbuffer + offset);
        memcpy( &(this->arrows[i]), &(this->st_arrows), sizeof(foxglove_msgs::ArrowPrimitive));
      }
      uint32_t cubes_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      cubes_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      cubes_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      cubes_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->cubes_length);
      if(cubes_lengthT > cubes_length)
        this->cubes = (foxglove_msgs::CubePrimitive*)realloc(this->cubes, cubes_lengthT * sizeof(foxglove_msgs::CubePrimitive));
      cubes_length = cubes_lengthT;
      for( uint32_t i = 0; i < cubes_length; i++){
      offset += this->st_cubes.deserialize(inbuffer + offset);
        memcpy( &(this->cubes[i]), &(this->st_cubes), sizeof(foxglove_msgs::CubePrimitive));
      }
      uint32_t spheres_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      spheres_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      spheres_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      spheres_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->spheres_length);
      if(spheres_lengthT > spheres_length)
        this->spheres = (foxglove_msgs::SpherePrimitive*)realloc(this->spheres, spheres_lengthT * sizeof(foxglove_msgs::SpherePrimitive));
      spheres_length = spheres_lengthT;
      for( uint32_t i = 0; i < spheres_length; i++){
      offset += this->st_spheres.deserialize(inbuffer + offset);
        memcpy( &(this->spheres[i]), &(this->st_spheres), sizeof(foxglove_msgs::SpherePrimitive));
      }
      uint32_t cylinders_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      cylinders_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      cylinders_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      cylinders_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->cylinders_length);
      if(cylinders_lengthT > cylinders_length)
        this->cylinders = (foxglove_msgs::CylinderPrimitive*)realloc(this->cylinders, cylinders_lengthT * sizeof(foxglove_msgs::CylinderPrimitive));
      cylinders_length = cylinders_lengthT;
      for( uint32_t i = 0; i < cylinders_length; i++){
      offset += this->st_cylinders.deserialize(inbuffer + offset);
        memcpy( &(this->cylinders[i]), &(this->st_cylinders), sizeof(foxglove_msgs::CylinderPrimitive));
      }
      uint32_t lines_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      lines_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      lines_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      lines_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->lines_length);
      if(lines_lengthT > lines_length)
        this->lines = (foxglove_msgs::LinePrimitive*)realloc(this->lines, lines_lengthT * sizeof(foxglove_msgs::LinePrimitive));
      lines_length = lines_lengthT;
      for( uint32_t i = 0; i < lines_length; i++){
      offset += this->st_lines.deserialize(inbuffer + offset);
        memcpy( &(this->lines[i]), &(this->st_lines), sizeof(foxglove_msgs::LinePrimitive));
      }
      uint32_t triangles_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      triangles_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      triangles_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      triangles_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->triangles_length);
      if(triangles_lengthT > triangles_length)
        this->triangles = (foxglove_msgs::TriangleListPrimitive*)realloc(this->triangles, triangles_lengthT * sizeof(foxglove_msgs::TriangleListPrimitive));
      triangles_length = triangles_lengthT;
      for( uint32_t i = 0; i < triangles_length; i++){
      offset += this->st_triangles.deserialize(inbuffer + offset);
        memcpy( &(this->triangles[i]), &(this->st_triangles), sizeof(foxglove_msgs::TriangleListPrimitive));
      }
      uint32_t texts_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      texts_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      texts_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      texts_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->texts_length);
      if(texts_lengthT > texts_length)
        this->texts = (foxglove_msgs::TextPrimitive*)realloc(this->texts, texts_lengthT * sizeof(foxglove_msgs::TextPrimitive));
      texts_length = texts_lengthT;
      for( uint32_t i = 0; i < texts_length; i++){
      offset += this->st_texts.deserialize(inbuffer + offset);
        memcpy( &(this->texts[i]), &(this->st_texts), sizeof(foxglove_msgs::TextPrimitive));
      }
      uint32_t models_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      models_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      models_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      models_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->models_length);
      if(models_lengthT > models_length)
        this->models = (foxglove_msgs::ModelPrimitive*)realloc(this->models, models_lengthT * sizeof(foxglove_msgs::ModelPrimitive));
      models_length = models_lengthT;
      for( uint32_t i = 0; i < models_length; i++){
      offset += this->st_models.deserialize(inbuffer + offset);
        memcpy( &(this->models[i]), &(this->st_models), sizeof(foxglove_msgs::ModelPrimitive));
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/SceneEntity"; };
    virtual const char * getMD5() override { return "0ef0f20344c30e92e1768ed896c46bd7"; };

  };

}
#endif
