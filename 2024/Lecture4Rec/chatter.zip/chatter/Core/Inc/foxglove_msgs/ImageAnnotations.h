#ifndef _ROS_foxglove_msgs_ImageAnnotations_h
#define _ROS_foxglove_msgs_ImageAnnotations_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "foxglove_msgs/CircleAnnotation.h"
#include "foxglove_msgs/PointsAnnotation.h"
#include "foxglove_msgs/TextAnnotation.h"

namespace foxglove_msgs
{

  class ImageAnnotations : public ros::Msg
  {
    public:
      uint32_t circles_length;
      typedef foxglove_msgs::CircleAnnotation _circles_type;
      _circles_type st_circles;
      _circles_type * circles;
      uint32_t points_length;
      typedef foxglove_msgs::PointsAnnotation _points_type;
      _points_type st_points;
      _points_type * points;
      uint32_t texts_length;
      typedef foxglove_msgs::TextAnnotation _texts_type;
      _texts_type st_texts;
      _texts_type * texts;

    ImageAnnotations():
      circles_length(0), st_circles(), circles(nullptr),
      points_length(0), st_points(), points(nullptr),
      texts_length(0), st_texts(), texts(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->circles_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->circles_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->circles_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->circles_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->circles_length);
      for( uint32_t i = 0; i < circles_length; i++){
      offset += this->circles[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->points_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->points_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->points_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->points_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->points_length);
      for( uint32_t i = 0; i < points_length; i++){
      offset += this->points[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->texts_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->texts_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->texts_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->texts_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->texts_length);
      for( uint32_t i = 0; i < texts_length; i++){
      offset += this->texts[i].serialize(outbuffer + offset);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      uint32_t circles_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      circles_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      circles_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      circles_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->circles_length);
      if(circles_lengthT > circles_length)
        this->circles = (foxglove_msgs::CircleAnnotation*)realloc(this->circles, circles_lengthT * sizeof(foxglove_msgs::CircleAnnotation));
      circles_length = circles_lengthT;
      for( uint32_t i = 0; i < circles_length; i++){
      offset += this->st_circles.deserialize(inbuffer + offset);
        memcpy( &(this->circles[i]), &(this->st_circles), sizeof(foxglove_msgs::CircleAnnotation));
      }
      uint32_t points_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->points_length);
      if(points_lengthT > points_length)
        this->points = (foxglove_msgs::PointsAnnotation*)realloc(this->points, points_lengthT * sizeof(foxglove_msgs::PointsAnnotation));
      points_length = points_lengthT;
      for( uint32_t i = 0; i < points_length; i++){
      offset += this->st_points.deserialize(inbuffer + offset);
        memcpy( &(this->points[i]), &(this->st_points), sizeof(foxglove_msgs::PointsAnnotation));
      }
      uint32_t texts_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      texts_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      texts_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      texts_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->texts_length);
      if(texts_lengthT > texts_length)
        this->texts = (foxglove_msgs::TextAnnotation*)realloc(this->texts, texts_lengthT * sizeof(foxglove_msgs::TextAnnotation));
      texts_length = texts_lengthT;
      for( uint32_t i = 0; i < texts_length; i++){
      offset += this->st_texts.deserialize(inbuffer + offset);
        memcpy( &(this->texts[i]), &(this->st_texts), sizeof(foxglove_msgs::TextAnnotation));
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/ImageAnnotations"; };
    virtual const char * getMD5() override { return "685a869995712c54b6863409ecf414b1"; };

  };

}
#endif
