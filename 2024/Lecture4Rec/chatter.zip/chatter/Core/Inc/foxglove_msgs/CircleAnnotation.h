#ifndef _ROS_foxglove_msgs_CircleAnnotation_h
#define _ROS_foxglove_msgs_CircleAnnotation_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "ros/time.h"
#include "foxglove_msgs/Point2.h"
#include "foxglove_msgs/Color.h"

namespace foxglove_msgs
{

  class CircleAnnotation : public ros::Msg
  {
    public:
      typedef ros::Time _timestamp_type;
      _timestamp_type timestamp;
      typedef foxglove_msgs::Point2 _position_type;
      _position_type position;
      typedef double _diameter_type;
      _diameter_type diameter;
      typedef double _thickness_type;
      _thickness_type thickness;
      typedef foxglove_msgs::Color _fill_color_type;
      _fill_color_type fill_color;
      typedef foxglove_msgs::Color _outline_color_type;
      _outline_color_type outline_color;

    CircleAnnotation():
      timestamp(),
      position(),
      diameter(0),
      thickness(0),
      fill_color(),
      outline_color()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->timestamp.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.sec);
      *(outbuffer + offset + 0) = (this->timestamp.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.nsec);
      offset += this->position.serialize(outbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_diameter;
      u_diameter.real = this->diameter;
      *(outbuffer + offset + 0) = (u_diameter.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_diameter.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_diameter.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_diameter.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_diameter.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_diameter.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_diameter.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_diameter.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->diameter);
      union {
        double real;
        uint64_t base;
      } u_thickness;
      u_thickness.real = this->thickness;
      *(outbuffer + offset + 0) = (u_thickness.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_thickness.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_thickness.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_thickness.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_thickness.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_thickness.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_thickness.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_thickness.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->thickness);
      offset += this->fill_color.serialize(outbuffer + offset);
      offset += this->outline_color.serialize(outbuffer + offset);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->timestamp.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.sec);
      this->timestamp.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.nsec);
      offset += this->position.deserialize(inbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_diameter;
      u_diameter.base = 0;
      u_diameter.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_diameter.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_diameter.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_diameter.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_diameter.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_diameter.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_diameter.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_diameter.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->diameter = u_diameter.real;
      offset += sizeof(this->diameter);
      union {
        double real;
        uint64_t base;
      } u_thickness;
      u_thickness.base = 0;
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_thickness.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->thickness = u_thickness.real;
      offset += sizeof(this->thickness);
      offset += this->fill_color.deserialize(inbuffer + offset);
      offset += this->outline_color.deserialize(inbuffer + offset);
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/CircleAnnotation"; };
    virtual const char * getMD5() override { return "625708f347af9680a6db92626081cc28"; };

  };

}
#endif
