#ifndef _ROS_foxglove_msgs_TrianglesMarker_h
#define _ROS_foxglove_msgs_TrianglesMarker_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "ros/time.h"
#include "ros/duration.h"
#include "foxglove_msgs/KeyValuePair.h"
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/Point.h"
#include "foxglove_msgs/Color.h"

namespace foxglove_msgs
{

  class TrianglesMarker : public ros::Msg
  {
    public:
      typedef ros::Time _timestamp_type;
      _timestamp_type timestamp;
      typedef const char* _frame_id_type;
      _frame_id_type frame_id;
      typedef const char* _id_type;
      _id_type id;
      typedef ros::Duration _lifetime_type;
      _lifetime_type lifetime;
      typedef bool _frame_locked_type;
      _frame_locked_type frame_locked;
      uint32_t metadata_length;
      typedef foxglove_msgs::KeyValuePair _metadata_type;
      _metadata_type st_metadata;
      _metadata_type * metadata;
      typedef geometry_msgs::Pose _pose_type;
      _pose_type pose;
      uint32_t points_length;
      typedef geometry_msgs::Point _points_type;
      _points_type st_points;
      _points_type * points;
      typedef foxglove_msgs::Color _color_type;
      _color_type color;
      uint32_t colors_length;
      typedef foxglove_msgs::Color _colors_type;
      _colors_type st_colors;
      _colors_type * colors;
      uint32_t indices_length;
      typedef uint32_t _indices_type;
      _indices_type st_indices;
      _indices_type * indices;

    TrianglesMarker():
      timestamp(),
      frame_id(""),
      id(""),
      lifetime(),
      frame_locked(0),
      metadata_length(0), st_metadata(), metadata(nullptr),
      pose(),
      points_length(0), st_points(), points(nullptr),
      color(),
      colors_length(0), st_colors(), colors(nullptr),
      indices_length(0), st_indices(), indices(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->timestamp.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.sec);
      *(outbuffer + offset + 0) = (this->timestamp.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id = strlen(this->frame_id);
      varToArr(outbuffer + offset, length_frame_id);
      offset += 4;
      memcpy(outbuffer + offset, this->frame_id, length_frame_id);
      offset += length_frame_id;
      uint32_t length_id = strlen(this->id);
      varToArr(outbuffer + offset, length_id);
      offset += 4;
      memcpy(outbuffer + offset, this->id, length_id);
      offset += length_id;
      *(outbuffer + offset + 0) = (this->lifetime.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->lifetime.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->lifetime.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->lifetime.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->lifetime.sec);
      *(outbuffer + offset + 0) = (this->lifetime.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->lifetime.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->lifetime.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->lifetime.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->lifetime.nsec);
      union {
        bool real;
        uint8_t base;
      } u_frame_locked;
      u_frame_locked.real = this->frame_locked;
      *(outbuffer + offset + 0) = (u_frame_locked.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->frame_locked);
      *(outbuffer + offset + 0) = (this->metadata_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->metadata_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->metadata_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->metadata_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->metadata_length);
      for( uint32_t i = 0; i < metadata_length; i++){
      offset += this->metadata[i].serialize(outbuffer + offset);
      }
      offset += this->pose.serialize(outbuffer + offset);
      *(outbuffer + offset + 0) = (this->points_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->points_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->points_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->points_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->points_length);
      for( uint32_t i = 0; i < points_length; i++){
      offset += this->points[i].serialize(outbuffer + offset);
      }
      offset += this->color.serialize(outbuffer + offset);
      *(outbuffer + offset + 0) = (this->colors_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->colors_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->colors_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->colors_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->colors_length);
      for( uint32_t i = 0; i < colors_length; i++){
      offset += this->colors[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->indices_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->indices_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->indices_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->indices_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->indices_length);
      for( uint32_t i = 0; i < indices_length; i++){
      *(outbuffer + offset + 0) = (this->indices[i] >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->indices[i] >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->indices[i] >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->indices[i] >> (8 * 3)) & 0xFF;
      offset += sizeof(this->indices[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->timestamp.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.sec);
      this->timestamp.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id;
      arrToVar(length_frame_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_frame_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_frame_id-1]=0;
      this->frame_id = (char *)(inbuffer + offset-1);
      offset += length_frame_id;
      uint32_t length_id;
      arrToVar(length_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_id-1]=0;
      this->id = (char *)(inbuffer + offset-1);
      offset += length_id;
      this->lifetime.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->lifetime.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->lifetime.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->lifetime.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->lifetime.sec);
      this->lifetime.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->lifetime.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->lifetime.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->lifetime.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->lifetime.nsec);
      union {
        bool real;
        uint8_t base;
      } u_frame_locked;
      u_frame_locked.base = 0;
      u_frame_locked.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->frame_locked = u_frame_locked.real;
      offset += sizeof(this->frame_locked);
      uint32_t metadata_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      metadata_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      metadata_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      metadata_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->metadata_length);
      if(metadata_lengthT > metadata_length)
        this->metadata = (foxglove_msgs::KeyValuePair*)realloc(this->metadata, metadata_lengthT * sizeof(foxglove_msgs::KeyValuePair));
      metadata_length = metadata_lengthT;
      for( uint32_t i = 0; i < metadata_length; i++){
      offset += this->st_metadata.deserialize(inbuffer + offset);
        memcpy( &(this->metadata[i]), &(this->st_metadata), sizeof(foxglove_msgs::KeyValuePair));
      }
      offset += this->pose.deserialize(inbuffer + offset);
      uint32_t points_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->points_length);
      if(points_lengthT > points_length)
        this->points = (geometry_msgs::Point*)realloc(this->points, points_lengthT * sizeof(geometry_msgs::Point));
      points_length = points_lengthT;
      for( uint32_t i = 0; i < points_length; i++){
      offset += this->st_points.deserialize(inbuffer + offset);
        memcpy( &(this->points[i]), &(this->st_points), sizeof(geometry_msgs::Point));
      }
      offset += this->color.deserialize(inbuffer + offset);
      uint32_t colors_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      colors_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      colors_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      colors_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->colors_length);
      if(colors_lengthT > colors_length)
        this->colors = (foxglove_msgs::Color*)realloc(this->colors, colors_lengthT * sizeof(foxglove_msgs::Color));
      colors_length = colors_lengthT;
      for( uint32_t i = 0; i < colors_length; i++){
      offset += this->st_colors.deserialize(inbuffer + offset);
        memcpy( &(this->colors[i]), &(this->st_colors), sizeof(foxglove_msgs::Color));
      }
      uint32_t indices_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      indices_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      indices_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      indices_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->indices_length);
      if(indices_lengthT > indices_length)
        this->indices = (uint32_t*)realloc(this->indices, indices_lengthT * sizeof(uint32_t));
      indices_length = indices_lengthT;
      for( uint32_t i = 0; i < indices_length; i++){
      this->st_indices =  ((uint32_t) (*(inbuffer + offset)));
      this->st_indices |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->st_indices |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->st_indices |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->st_indices);
        memcpy( &(this->indices[i]), &(this->st_indices), sizeof(uint32_t));
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/TrianglesMarker"; };
    virtual const char * getMD5() override { return "f365629c151dfe98b2231f3864f8af4b"; };

  };

}
#endif
