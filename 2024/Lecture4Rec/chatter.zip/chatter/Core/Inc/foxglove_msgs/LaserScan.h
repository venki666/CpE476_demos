#ifndef _ROS_foxglove_msgs_LaserScan_h
#define _ROS_foxglove_msgs_LaserScan_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "ros/time.h"
#include "geometry_msgs/Pose.h"

namespace foxglove_msgs
{

  class LaserScan : public ros::Msg
  {
    public:
      typedef ros::Time _timestamp_type;
      _timestamp_type timestamp;
      typedef const char* _frame_id_type;
      _frame_id_type frame_id;
      typedef geometry_msgs::Pose _pose_type;
      _pose_type pose;
      typedef double _start_angle_type;
      _start_angle_type start_angle;
      typedef double _end_angle_type;
      _end_angle_type end_angle;
      uint32_t ranges_length;
      typedef double _ranges_type;
      _ranges_type st_ranges;
      _ranges_type * ranges;
      uint32_t intensities_length;
      typedef double _intensities_type;
      _intensities_type st_intensities;
      _intensities_type * intensities;

    LaserScan():
      timestamp(),
      frame_id(""),
      pose(),
      start_angle(0),
      end_angle(0),
      ranges_length(0), st_ranges(), ranges(nullptr),
      intensities_length(0), st_intensities(), intensities(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->timestamp.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.sec);
      *(outbuffer + offset + 0) = (this->timestamp.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id = strlen(this->frame_id);
      varToArr(outbuffer + offset, length_frame_id);
      offset += 4;
      memcpy(outbuffer + offset, this->frame_id, length_frame_id);
      offset += length_frame_id;
      offset += this->pose.serialize(outbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_start_angle;
      u_start_angle.real = this->start_angle;
      *(outbuffer + offset + 0) = (u_start_angle.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_start_angle.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_start_angle.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_start_angle.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_start_angle.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_start_angle.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_start_angle.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_start_angle.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->start_angle);
      union {
        double real;
        uint64_t base;
      } u_end_angle;
      u_end_angle.real = this->end_angle;
      *(outbuffer + offset + 0) = (u_end_angle.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_end_angle.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_end_angle.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_end_angle.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_end_angle.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_end_angle.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_end_angle.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_end_angle.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->end_angle);
      *(outbuffer + offset + 0) = (this->ranges_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->ranges_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->ranges_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->ranges_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->ranges_length);
      for( uint32_t i = 0; i < ranges_length; i++){
      union {
        double real;
        uint64_t base;
      } u_rangesi;
      u_rangesi.real = this->ranges[i];
      *(outbuffer + offset + 0) = (u_rangesi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_rangesi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_rangesi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_rangesi.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_rangesi.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_rangesi.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_rangesi.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_rangesi.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->ranges[i]);
      }
      *(outbuffer + offset + 0) = (this->intensities_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->intensities_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->intensities_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->intensities_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->intensities_length);
      for( uint32_t i = 0; i < intensities_length; i++){
      union {
        double real;
        uint64_t base;
      } u_intensitiesi;
      u_intensitiesi.real = this->intensities[i];
      *(outbuffer + offset + 0) = (u_intensitiesi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_intensitiesi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_intensitiesi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_intensitiesi.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_intensitiesi.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_intensitiesi.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_intensitiesi.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_intensitiesi.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->intensities[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->timestamp.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.sec);
      this->timestamp.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id;
      arrToVar(length_frame_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_frame_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_frame_id-1]=0;
      this->frame_id = (char *)(inbuffer + offset-1);
      offset += length_frame_id;
      offset += this->pose.deserialize(inbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_start_angle;
      u_start_angle.base = 0;
      u_start_angle.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_start_angle.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_start_angle.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_start_angle.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_start_angle.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_start_angle.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_start_angle.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_start_angle.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->start_angle = u_start_angle.real;
      offset += sizeof(this->start_angle);
      union {
        double real;
        uint64_t base;
      } u_end_angle;
      u_end_angle.base = 0;
      u_end_angle.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_end_angle.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_end_angle.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_end_angle.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_end_angle.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_end_angle.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_end_angle.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_end_angle.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->end_angle = u_end_angle.real;
      offset += sizeof(this->end_angle);
      uint32_t ranges_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      ranges_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      ranges_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      ranges_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->ranges_length);
      if(ranges_lengthT > ranges_length)
        this->ranges = (double*)realloc(this->ranges, ranges_lengthT * sizeof(double));
      ranges_length = ranges_lengthT;
      for( uint32_t i = 0; i < ranges_length; i++){
      union {
        double real;
        uint64_t base;
      } u_st_ranges;
      u_st_ranges.base = 0;
      u_st_ranges.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_ranges.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_ranges.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_ranges.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_st_ranges.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_st_ranges.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_st_ranges.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_st_ranges.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->st_ranges = u_st_ranges.real;
      offset += sizeof(this->st_ranges);
        memcpy( &(this->ranges[i]), &(this->st_ranges), sizeof(double));
      }
      uint32_t intensities_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      intensities_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      intensities_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      intensities_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->intensities_length);
      if(intensities_lengthT > intensities_length)
        this->intensities = (double*)realloc(this->intensities, intensities_lengthT * sizeof(double));
      intensities_length = intensities_lengthT;
      for( uint32_t i = 0; i < intensities_length; i++){
      union {
        double real;
        uint64_t base;
      } u_st_intensities;
      u_st_intensities.base = 0;
      u_st_intensities.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_intensities.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_intensities.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_intensities.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_st_intensities.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_st_intensities.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_st_intensities.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_st_intensities.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->st_intensities = u_st_intensities.real;
      offset += sizeof(this->st_intensities);
        memcpy( &(this->intensities[i]), &(this->st_intensities), sizeof(double));
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/LaserScan"; };
    virtual const char * getMD5() override { return "38d9665acff9bd72043c5a392c9213a4"; };

  };

}
#endif
