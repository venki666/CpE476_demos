#ifndef _ROS_foxglove_msgs_TextMarker_h
#define _ROS_foxglove_msgs_TextMarker_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "geometry_msgs/Pose.h"
#include "foxglove_msgs/Color.h"

namespace foxglove_msgs
{

  class TextMarker : public ros::Msg
  {
    public:
      typedef geometry_msgs::Pose _pose_type;
      _pose_type pose;
      typedef bool _billboard_type;
      _billboard_type billboard;
      typedef double _font_size_type;
      _font_size_type font_size;
      typedef bool _scale_invariant_type;
      _scale_invariant_type scale_invariant;
      typedef foxglove_msgs::Color _color_type;
      _color_type color;
      typedef const char* _text_type;
      _text_type text;

    TextMarker():
      pose(),
      billboard(0),
      font_size(0),
      scale_invariant(0),
      color(),
      text("")
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += this->pose.serialize(outbuffer + offset);
      union {
        bool real;
        uint8_t base;
      } u_billboard;
      u_billboard.real = this->billboard;
      *(outbuffer + offset + 0) = (u_billboard.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->billboard);
      union {
        double real;
        uint64_t base;
      } u_font_size;
      u_font_size.real = this->font_size;
      *(outbuffer + offset + 0) = (u_font_size.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_font_size.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_font_size.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_font_size.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_font_size.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_font_size.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_font_size.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_font_size.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->font_size);
      union {
        bool real;
        uint8_t base;
      } u_scale_invariant;
      u_scale_invariant.real = this->scale_invariant;
      *(outbuffer + offset + 0) = (u_scale_invariant.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->scale_invariant);
      offset += this->color.serialize(outbuffer + offset);
      uint32_t length_text = strlen(this->text);
      varToArr(outbuffer + offset, length_text);
      offset += 4;
      memcpy(outbuffer + offset, this->text, length_text);
      offset += length_text;
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += this->pose.deserialize(inbuffer + offset);
      union {
        bool real;
        uint8_t base;
      } u_billboard;
      u_billboard.base = 0;
      u_billboard.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->billboard = u_billboard.real;
      offset += sizeof(this->billboard);
      union {
        double real;
        uint64_t base;
      } u_font_size;
      u_font_size.base = 0;
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_font_size.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->font_size = u_font_size.real;
      offset += sizeof(this->font_size);
      union {
        bool real;
        uint8_t base;
      } u_scale_invariant;
      u_scale_invariant.base = 0;
      u_scale_invariant.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->scale_invariant = u_scale_invariant.real;
      offset += sizeof(this->scale_invariant);
      offset += this->color.deserialize(inbuffer + offset);
      uint32_t length_text;
      arrToVar(length_text, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_text; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_text-1]=0;
      this->text = (char *)(inbuffer + offset-1);
      offset += length_text;
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/TextMarker"; };
    virtual const char * getMD5() override { return "bec1b8536471438a5b2697ab2d6c5ca1"; };

  };

}
#endif
