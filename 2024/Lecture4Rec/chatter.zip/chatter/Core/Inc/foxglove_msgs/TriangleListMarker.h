#ifndef _ROS_foxglove_msgs_TriangleListMarker_h
#define _ROS_foxglove_msgs_TriangleListMarker_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/Point.h"
#include "foxglove_msgs/Color.h"

namespace foxglove_msgs
{

  class TriangleListMarker : public ros::Msg
  {
    public:
      typedef geometry_msgs::Pose _pose_type;
      _pose_type pose;
      uint32_t points_length;
      typedef geometry_msgs::Point _points_type;
      _points_type st_points;
      _points_type * points;
      typedef foxglove_msgs::Color _color_type;
      _color_type color;
      uint32_t colors_length;
      typedef foxglove_msgs::Color _colors_type;
      _colors_type st_colors;
      _colors_type * colors;
      uint32_t indices_length;
      typedef uint32_t _indices_type;
      _indices_type st_indices;
      _indices_type * indices;

    TriangleListMarker():
      pose(),
      points_length(0), st_points(), points(nullptr),
      color(),
      colors_length(0), st_colors(), colors(nullptr),
      indices_length(0), st_indices(), indices(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += this->pose.serialize(outbuffer + offset);
      *(outbuffer + offset + 0) = (this->points_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->points_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->points_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->points_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->points_length);
      for( uint32_t i = 0; i < points_length; i++){
      offset += this->points[i].serialize(outbuffer + offset);
      }
      offset += this->color.serialize(outbuffer + offset);
      *(outbuffer + offset + 0) = (this->colors_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->colors_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->colors_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->colors_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->colors_length);
      for( uint32_t i = 0; i < colors_length; i++){
      offset += this->colors[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->indices_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->indices_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->indices_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->indices_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->indices_length);
      for( uint32_t i = 0; i < indices_length; i++){
      *(outbuffer + offset + 0) = (this->indices[i] >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->indices[i] >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->indices[i] >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->indices[i] >> (8 * 3)) & 0xFF;
      offset += sizeof(this->indices[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += this->pose.deserialize(inbuffer + offset);
      uint32_t points_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      points_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->points_length);
      if(points_lengthT > points_length)
        this->points = (geometry_msgs::Point*)realloc(this->points, points_lengthT * sizeof(geometry_msgs::Point));
      points_length = points_lengthT;
      for( uint32_t i = 0; i < points_length; i++){
      offset += this->st_points.deserialize(inbuffer + offset);
        memcpy( &(this->points[i]), &(this->st_points), sizeof(geometry_msgs::Point));
      }
      offset += this->color.deserialize(inbuffer + offset);
      uint32_t colors_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      colors_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      colors_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      colors_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->colors_length);
      if(colors_lengthT > colors_length)
        this->colors = (foxglove_msgs::Color*)realloc(this->colors, colors_lengthT * sizeof(foxglove_msgs::Color));
      colors_length = colors_lengthT;
      for( uint32_t i = 0; i < colors_length; i++){
      offset += this->st_colors.deserialize(inbuffer + offset);
        memcpy( &(this->colors[i]), &(this->st_colors), sizeof(foxglove_msgs::Color));
      }
      uint32_t indices_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      indices_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      indices_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      indices_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->indices_length);
      if(indices_lengthT > indices_length)
        this->indices = (uint32_t*)realloc(this->indices, indices_lengthT * sizeof(uint32_t));
      indices_length = indices_lengthT;
      for( uint32_t i = 0; i < indices_length; i++){
      this->st_indices =  ((uint32_t) (*(inbuffer + offset)));
      this->st_indices |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->st_indices |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->st_indices |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->st_indices);
        memcpy( &(this->indices[i]), &(this->st_indices), sizeof(uint32_t));
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/TriangleListMarker"; };
    virtual const char * getMD5() override { return "31ba9e95731d693961104fd1f10cfb75"; };

  };

}
#endif
