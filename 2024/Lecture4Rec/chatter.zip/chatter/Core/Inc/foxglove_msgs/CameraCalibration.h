#ifndef _ROS_foxglove_msgs_CameraCalibration_h
#define _ROS_foxglove_msgs_CameraCalibration_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "ros/time.h"

namespace foxglove_msgs
{

  class CameraCalibration : public ros::Msg
  {
    public:
      typedef ros::Time _timestamp_type;
      _timestamp_type timestamp;
      typedef const char* _frame_id_type;
      _frame_id_type frame_id;
      typedef uint32_t _width_type;
      _width_type width;
      typedef uint32_t _height_type;
      _height_type height;
      typedef const char* _distortion_model_type;
      _distortion_model_type distortion_model;
      uint32_t D_length;
      typedef double _D_type;
      _D_type st_D;
      _D_type * D;
      double K[9];
      double R[9];
      double P[12];

    CameraCalibration():
      timestamp(),
      frame_id(""),
      width(0),
      height(0),
      distortion_model(""),
      D_length(0), st_D(), D(nullptr),
      K(),
      R(),
      P()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->timestamp.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.sec);
      *(outbuffer + offset + 0) = (this->timestamp.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id = strlen(this->frame_id);
      varToArr(outbuffer + offset, length_frame_id);
      offset += 4;
      memcpy(outbuffer + offset, this->frame_id, length_frame_id);
      offset += length_frame_id;
      *(outbuffer + offset + 0) = (this->width >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->width >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->width >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->width >> (8 * 3)) & 0xFF;
      offset += sizeof(this->width);
      *(outbuffer + offset + 0) = (this->height >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->height >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->height >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->height >> (8 * 3)) & 0xFF;
      offset += sizeof(this->height);
      uint32_t length_distortion_model = strlen(this->distortion_model);
      varToArr(outbuffer + offset, length_distortion_model);
      offset += 4;
      memcpy(outbuffer + offset, this->distortion_model, length_distortion_model);
      offset += length_distortion_model;
      *(outbuffer + offset + 0) = (this->D_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->D_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->D_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->D_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->D_length);
      for( uint32_t i = 0; i < D_length; i++){
      union {
        double real;
        uint64_t base;
      } u_Di;
      u_Di.real = this->D[i];
      *(outbuffer + offset + 0) = (u_Di.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_Di.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_Di.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_Di.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_Di.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_Di.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_Di.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_Di.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->D[i]);
      }
      for( uint32_t i = 0; i < 9; i++){
      union {
        double real;
        uint64_t base;
      } u_Ki;
      u_Ki.real = this->K[i];
      *(outbuffer + offset + 0) = (u_Ki.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_Ki.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_Ki.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_Ki.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_Ki.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_Ki.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_Ki.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_Ki.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->K[i]);
      }
      for( uint32_t i = 0; i < 9; i++){
      union {
        double real;
        uint64_t base;
      } u_Ri;
      u_Ri.real = this->R[i];
      *(outbuffer + offset + 0) = (u_Ri.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_Ri.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_Ri.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_Ri.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_Ri.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_Ri.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_Ri.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_Ri.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->R[i]);
      }
      for( uint32_t i = 0; i < 12; i++){
      union {
        double real;
        uint64_t base;
      } u_Pi;
      u_Pi.real = this->P[i];
      *(outbuffer + offset + 0) = (u_Pi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_Pi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_Pi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_Pi.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_Pi.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_Pi.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_Pi.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_Pi.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->P[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->timestamp.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.sec);
      this->timestamp.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id;
      arrToVar(length_frame_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_frame_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_frame_id-1]=0;
      this->frame_id = (char *)(inbuffer + offset-1);
      offset += length_frame_id;
      this->width =  ((uint32_t) (*(inbuffer + offset)));
      this->width |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->width |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->width |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->width);
      this->height =  ((uint32_t) (*(inbuffer + offset)));
      this->height |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->height |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->height |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->height);
      uint32_t length_distortion_model;
      arrToVar(length_distortion_model, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_distortion_model; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_distortion_model-1]=0;
      this->distortion_model = (char *)(inbuffer + offset-1);
      offset += length_distortion_model;
      uint32_t D_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      D_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      D_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      D_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->D_length);
      if(D_lengthT > D_length)
        this->D = (double*)realloc(this->D, D_lengthT * sizeof(double));
      D_length = D_lengthT;
      for( uint32_t i = 0; i < D_length; i++){
      union {
        double real;
        uint64_t base;
      } u_st_D;
      u_st_D.base = 0;
      u_st_D.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_D.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_D.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_D.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_st_D.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_st_D.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_st_D.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_st_D.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->st_D = u_st_D.real;
      offset += sizeof(this->st_D);
        memcpy( &(this->D[i]), &(this->st_D), sizeof(double));
      }
      for( uint32_t i = 0; i < 9; i++){
      union {
        double real;
        uint64_t base;
      } u_Ki;
      u_Ki.base = 0;
      u_Ki.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_Ki.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_Ki.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_Ki.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_Ki.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_Ki.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_Ki.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_Ki.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->K[i] = u_Ki.real;
      offset += sizeof(this->K[i]);
      }
      for( uint32_t i = 0; i < 9; i++){
      union {
        double real;
        uint64_t base;
      } u_Ri;
      u_Ri.base = 0;
      u_Ri.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_Ri.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_Ri.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_Ri.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_Ri.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_Ri.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_Ri.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_Ri.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->R[i] = u_Ri.real;
      offset += sizeof(this->R[i]);
      }
      for( uint32_t i = 0; i < 12; i++){
      union {
        double real;
        uint64_t base;
      } u_Pi;
      u_Pi.base = 0;
      u_Pi.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_Pi.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_Pi.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_Pi.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_Pi.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_Pi.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_Pi.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_Pi.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->P[i] = u_Pi.real;
      offset += sizeof(this->P[i]);
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/CameraCalibration"; };
    virtual const char * getMD5() override { return "a208aa8d11a148c3edd1fc117b079143"; };

  };

}
#endif
