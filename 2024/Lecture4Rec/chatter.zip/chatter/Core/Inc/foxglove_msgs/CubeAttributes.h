#ifndef _ROS_foxglove_msgs_CubeAttributes_h
#define _ROS_foxglove_msgs_CubeAttributes_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/Vector3.h"
#include "foxglove_msgs/Color.h"

namespace foxglove_msgs
{

  class CubeAttributes : public ros::Msg
  {
    public:
      typedef geometry_msgs::Pose _pose_type;
      _pose_type pose;
      typedef geometry_msgs::Vector3 _size_type;
      _size_type size;
      typedef foxglove_msgs::Color _color_type;
      _color_type color;

    CubeAttributes():
      pose(),
      size(),
      color()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += this->pose.serialize(outbuffer + offset);
      offset += this->size.serialize(outbuffer + offset);
      offset += this->color.serialize(outbuffer + offset);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += this->pose.deserialize(inbuffer + offset);
      offset += this->size.deserialize(inbuffer + offset);
      offset += this->color.deserialize(inbuffer + offset);
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/CubeAttributes"; };
    virtual const char * getMD5() override { return "c87ddcef975c2f7cea110701586453ab"; };

  };

}
#endif
