#ifndef _ROS_foxglove_msgs_ModelPrimitive_h
#define _ROS_foxglove_msgs_ModelPrimitive_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/Vector3.h"
#include "foxglove_msgs/Color.h"

namespace foxglove_msgs
{

  class ModelPrimitive : public ros::Msg
  {
    public:
      typedef geometry_msgs::Pose _pose_type;
      _pose_type pose;
      typedef geometry_msgs::Vector3 _scale_type;
      _scale_type scale;
      typedef foxglove_msgs::Color _color_type;
      _color_type color;
      typedef bool _override_color_type;
      _override_color_type override_color;
      typedef const char* _url_type;
      _url_type url;
      typedef const char* _media_type_type;
      _media_type_type media_type;
      uint32_t data_length;
      typedef uint8_t _data_type;
      _data_type st_data;
      _data_type * data;

    ModelPrimitive():
      pose(),
      scale(),
      color(),
      override_color(0),
      url(""),
      media_type(""),
      data_length(0), st_data(), data(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += this->pose.serialize(outbuffer + offset);
      offset += this->scale.serialize(outbuffer + offset);
      offset += this->color.serialize(outbuffer + offset);
      union {
        bool real;
        uint8_t base;
      } u_override_color;
      u_override_color.real = this->override_color;
      *(outbuffer + offset + 0) = (u_override_color.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->override_color);
      uint32_t length_url = strlen(this->url);
      varToArr(outbuffer + offset, length_url);
      offset += 4;
      memcpy(outbuffer + offset, this->url, length_url);
      offset += length_url;
      uint32_t length_media_type = strlen(this->media_type);
      varToArr(outbuffer + offset, length_media_type);
      offset += 4;
      memcpy(outbuffer + offset, this->media_type, length_media_type);
      offset += length_media_type;
      *(outbuffer + offset + 0) = (this->data_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->data_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->data_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->data_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->data_length);
      for( uint32_t i = 0; i < data_length; i++){
      *(outbuffer + offset + 0) = (this->data[i] >> (8 * 0)) & 0xFF;
      offset += sizeof(this->data[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += this->pose.deserialize(inbuffer + offset);
      offset += this->scale.deserialize(inbuffer + offset);
      offset += this->color.deserialize(inbuffer + offset);
      union {
        bool real;
        uint8_t base;
      } u_override_color;
      u_override_color.base = 0;
      u_override_color.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->override_color = u_override_color.real;
      offset += sizeof(this->override_color);
      uint32_t length_url;
      arrToVar(length_url, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_url; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_url-1]=0;
      this->url = (char *)(inbuffer + offset-1);
      offset += length_url;
      uint32_t length_media_type;
      arrToVar(length_media_type, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_media_type; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_media_type-1]=0;
      this->media_type = (char *)(inbuffer + offset-1);
      offset += length_media_type;
      uint32_t data_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      data_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      data_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      data_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->data_length);
      if(data_lengthT > data_length)
        this->data = (uint8_t*)realloc(this->data, data_lengthT * sizeof(uint8_t));
      data_length = data_lengthT;
      for( uint32_t i = 0; i < data_length; i++){
      this->st_data =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->st_data);
        memcpy( &(this->data[i]), &(this->st_data), sizeof(uint8_t));
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/ModelPrimitive"; };
    virtual const char * getMD5() override { return "da16edf657feee05cf9ccf39dec781a1"; };

  };

}
#endif
