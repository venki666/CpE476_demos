#ifndef _ROS_foxglove_msgs_CylinderMarker_h
#define _ROS_foxglove_msgs_CylinderMarker_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "ros/time.h"
#include "ros/duration.h"
#include "foxglove_msgs/KeyValuePair.h"
#include "geometry_msgs/Pose.h"
#include "foxglove_msgs/Color.h"

namespace foxglove_msgs
{

  class CylinderMarker : public ros::Msg
  {
    public:
      typedef ros::Time _timestamp_type;
      _timestamp_type timestamp;
      typedef const char* _frame_id_type;
      _frame_id_type frame_id;
      typedef const char* _id_type;
      _id_type id;
      typedef ros::Duration _lifetime_type;
      _lifetime_type lifetime;
      typedef bool _frame_locked_type;
      _frame_locked_type frame_locked;
      uint32_t metadata_length;
      typedef foxglove_msgs::KeyValuePair _metadata_type;
      _metadata_type st_metadata;
      _metadata_type * metadata;
      typedef geometry_msgs::Pose _pose_type;
      _pose_type pose;
      typedef double _bottom_radius_type;
      _bottom_radius_type bottom_radius;
      typedef double _top_radius_type;
      _top_radius_type top_radius;
      typedef double _height_type;
      _height_type height;
      typedef foxglove_msgs::Color _color_type;
      _color_type color;

    CylinderMarker():
      timestamp(),
      frame_id(""),
      id(""),
      lifetime(),
      frame_locked(0),
      metadata_length(0), st_metadata(), metadata(nullptr),
      pose(),
      bottom_radius(0),
      top_radius(0),
      height(0),
      color()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->timestamp.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.sec);
      *(outbuffer + offset + 0) = (this->timestamp.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id = strlen(this->frame_id);
      varToArr(outbuffer + offset, length_frame_id);
      offset += 4;
      memcpy(outbuffer + offset, this->frame_id, length_frame_id);
      offset += length_frame_id;
      uint32_t length_id = strlen(this->id);
      varToArr(outbuffer + offset, length_id);
      offset += 4;
      memcpy(outbuffer + offset, this->id, length_id);
      offset += length_id;
      *(outbuffer + offset + 0) = (this->lifetime.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->lifetime.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->lifetime.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->lifetime.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->lifetime.sec);
      *(outbuffer + offset + 0) = (this->lifetime.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->lifetime.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->lifetime.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->lifetime.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->lifetime.nsec);
      union {
        bool real;
        uint8_t base;
      } u_frame_locked;
      u_frame_locked.real = this->frame_locked;
      *(outbuffer + offset + 0) = (u_frame_locked.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->frame_locked);
      *(outbuffer + offset + 0) = (this->metadata_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->metadata_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->metadata_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->metadata_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->metadata_length);
      for( uint32_t i = 0; i < metadata_length; i++){
      offset += this->metadata[i].serialize(outbuffer + offset);
      }
      offset += this->pose.serialize(outbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_bottom_radius;
      u_bottom_radius.real = this->bottom_radius;
      *(outbuffer + offset + 0) = (u_bottom_radius.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_bottom_radius.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_bottom_radius.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_bottom_radius.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_bottom_radius.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_bottom_radius.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_bottom_radius.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_bottom_radius.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->bottom_radius);
      union {
        double real;
        uint64_t base;
      } u_top_radius;
      u_top_radius.real = this->top_radius;
      *(outbuffer + offset + 0) = (u_top_radius.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_top_radius.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_top_radius.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_top_radius.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_top_radius.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_top_radius.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_top_radius.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_top_radius.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->top_radius);
      union {
        double real;
        uint64_t base;
      } u_height;
      u_height.real = this->height;
      *(outbuffer + offset + 0) = (u_height.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_height.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_height.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_height.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_height.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_height.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_height.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_height.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->height);
      offset += this->color.serialize(outbuffer + offset);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->timestamp.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.sec);
      this->timestamp.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id;
      arrToVar(length_frame_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_frame_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_frame_id-1]=0;
      this->frame_id = (char *)(inbuffer + offset-1);
      offset += length_frame_id;
      uint32_t length_id;
      arrToVar(length_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_id-1]=0;
      this->id = (char *)(inbuffer + offset-1);
      offset += length_id;
      this->lifetime.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->lifetime.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->lifetime.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->lifetime.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->lifetime.sec);
      this->lifetime.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->lifetime.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->lifetime.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->lifetime.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->lifetime.nsec);
      union {
        bool real;
        uint8_t base;
      } u_frame_locked;
      u_frame_locked.base = 0;
      u_frame_locked.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->frame_locked = u_frame_locked.real;
      offset += sizeof(this->frame_locked);
      uint32_t metadata_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      metadata_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      metadata_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      metadata_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->metadata_length);
      if(metadata_lengthT > metadata_length)
        this->metadata = (foxglove_msgs::KeyValuePair*)realloc(this->metadata, metadata_lengthT * sizeof(foxglove_msgs::KeyValuePair));
      metadata_length = metadata_lengthT;
      for( uint32_t i = 0; i < metadata_length; i++){
      offset += this->st_metadata.deserialize(inbuffer + offset);
        memcpy( &(this->metadata[i]), &(this->st_metadata), sizeof(foxglove_msgs::KeyValuePair));
      }
      offset += this->pose.deserialize(inbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_bottom_radius;
      u_bottom_radius.base = 0;
      u_bottom_radius.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_bottom_radius.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_bottom_radius.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_bottom_radius.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_bottom_radius.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_bottom_radius.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_bottom_radius.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_bottom_radius.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->bottom_radius = u_bottom_radius.real;
      offset += sizeof(this->bottom_radius);
      union {
        double real;
        uint64_t base;
      } u_top_radius;
      u_top_radius.base = 0;
      u_top_radius.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_top_radius.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_top_radius.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_top_radius.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_top_radius.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_top_radius.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_top_radius.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_top_radius.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->top_radius = u_top_radius.real;
      offset += sizeof(this->top_radius);
      union {
        double real;
        uint64_t base;
      } u_height;
      u_height.base = 0;
      u_height.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_height.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_height.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_height.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_height.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_height.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_height.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_height.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->height = u_height.real;
      offset += sizeof(this->height);
      offset += this->color.deserialize(inbuffer + offset);
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/CylinderMarker"; };
    virtual const char * getMD5() override { return "cc5444b6ee614fc21ef1845f5e417169"; };

  };

}
#endif
