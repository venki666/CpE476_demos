#ifndef _ROS_foxglove_msgs_Markers_h
#define _ROS_foxglove_msgs_Markers_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "foxglove_msgs/MarkerDeletion.h"
#include "foxglove_msgs/ArrowMarker.h"
#include "foxglove_msgs/CubeListMarker.h"
#include "foxglove_msgs/SphereListMarker.h"
#include "foxglove_msgs/ConeListMarker.h"
#include "foxglove_msgs/LineMarker.h"
#include "foxglove_msgs/TriangleListMarker.h"
#include "foxglove_msgs/TextMarker.h"
#include "foxglove_msgs/ModelMarker.h"

namespace foxglove_msgs
{

  class Markers : public ros::Msg
  {
    public:
      uint32_t deletions_length;
      typedef foxglove_msgs::MarkerDeletion _deletions_type;
      _deletions_type st_deletions;
      _deletions_type * deletions;
      uint32_t arrows_length;
      typedef foxglove_msgs::ArrowMarker _arrows_type;
      _arrows_type st_arrows;
      _arrows_type * arrows;
      uint32_t cubes_length;
      typedef foxglove_msgs::CubeListMarker _cubes_type;
      _cubes_type st_cubes;
      _cubes_type * cubes;
      uint32_t spheres_length;
      typedef foxglove_msgs::SphereListMarker _spheres_type;
      _spheres_type st_spheres;
      _spheres_type * spheres;
      uint32_t cones_length;
      typedef foxglove_msgs::ConeListMarker _cones_type;
      _cones_type st_cones;
      _cones_type * cones;
      uint32_t lines_length;
      typedef foxglove_msgs::LineMarker _lines_type;
      _lines_type st_lines;
      _lines_type * lines;
      uint32_t triangles_length;
      typedef foxglove_msgs::TriangleListMarker _triangles_type;
      _triangles_type st_triangles;
      _triangles_type * triangles;
      uint32_t texts_length;
      typedef foxglove_msgs::TextMarker _texts_type;
      _texts_type st_texts;
      _texts_type * texts;
      uint32_t models_length;
      typedef foxglove_msgs::ModelMarker _models_type;
      _models_type st_models;
      _models_type * models;

    Markers():
      deletions_length(0), st_deletions(), deletions(nullptr),
      arrows_length(0), st_arrows(), arrows(nullptr),
      cubes_length(0), st_cubes(), cubes(nullptr),
      spheres_length(0), st_spheres(), spheres(nullptr),
      cones_length(0), st_cones(), cones(nullptr),
      lines_length(0), st_lines(), lines(nullptr),
      triangles_length(0), st_triangles(), triangles(nullptr),
      texts_length(0), st_texts(), texts(nullptr),
      models_length(0), st_models(), models(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->deletions_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->deletions_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->deletions_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->deletions_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->deletions_length);
      for( uint32_t i = 0; i < deletions_length; i++){
      offset += this->deletions[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->arrows_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->arrows_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->arrows_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->arrows_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->arrows_length);
      for( uint32_t i = 0; i < arrows_length; i++){
      offset += this->arrows[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->cubes_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->cubes_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->cubes_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->cubes_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->cubes_length);
      for( uint32_t i = 0; i < cubes_length; i++){
      offset += this->cubes[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->spheres_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->spheres_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->spheres_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->spheres_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->spheres_length);
      for( uint32_t i = 0; i < spheres_length; i++){
      offset += this->spheres[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->cones_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->cones_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->cones_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->cones_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->cones_length);
      for( uint32_t i = 0; i < cones_length; i++){
      offset += this->cones[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->lines_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->lines_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->lines_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->lines_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->lines_length);
      for( uint32_t i = 0; i < lines_length; i++){
      offset += this->lines[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->triangles_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->triangles_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->triangles_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->triangles_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->triangles_length);
      for( uint32_t i = 0; i < triangles_length; i++){
      offset += this->triangles[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->texts_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->texts_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->texts_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->texts_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->texts_length);
      for( uint32_t i = 0; i < texts_length; i++){
      offset += this->texts[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->models_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->models_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->models_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->models_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->models_length);
      for( uint32_t i = 0; i < models_length; i++){
      offset += this->models[i].serialize(outbuffer + offset);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      uint32_t deletions_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      deletions_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      deletions_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      deletions_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->deletions_length);
      if(deletions_lengthT > deletions_length)
        this->deletions = (foxglove_msgs::MarkerDeletion*)realloc(this->deletions, deletions_lengthT * sizeof(foxglove_msgs::MarkerDeletion));
      deletions_length = deletions_lengthT;
      for( uint32_t i = 0; i < deletions_length; i++){
      offset += this->st_deletions.deserialize(inbuffer + offset);
        memcpy( &(this->deletions[i]), &(this->st_deletions), sizeof(foxglove_msgs::MarkerDeletion));
      }
      uint32_t arrows_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      arrows_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      arrows_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      arrows_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->arrows_length);
      if(arrows_lengthT > arrows_length)
        this->arrows = (foxglove_msgs::ArrowMarker*)realloc(this->arrows, arrows_lengthT * sizeof(foxglove_msgs::ArrowMarker));
      arrows_length = arrows_lengthT;
      for( uint32_t i = 0; i < arrows_length; i++){
      offset += this->st_arrows.deserialize(inbuffer + offset);
        memcpy( &(this->arrows[i]), &(this->st_arrows), sizeof(foxglove_msgs::ArrowMarker));
      }
      uint32_t cubes_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      cubes_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      cubes_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      cubes_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->cubes_length);
      if(cubes_lengthT > cubes_length)
        this->cubes = (foxglove_msgs::CubeListMarker*)realloc(this->cubes, cubes_lengthT * sizeof(foxglove_msgs::CubeListMarker));
      cubes_length = cubes_lengthT;
      for( uint32_t i = 0; i < cubes_length; i++){
      offset += this->st_cubes.deserialize(inbuffer + offset);
        memcpy( &(this->cubes[i]), &(this->st_cubes), sizeof(foxglove_msgs::CubeListMarker));
      }
      uint32_t spheres_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      spheres_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      spheres_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      spheres_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->spheres_length);
      if(spheres_lengthT > spheres_length)
        this->spheres = (foxglove_msgs::SphereListMarker*)realloc(this->spheres, spheres_lengthT * sizeof(foxglove_msgs::SphereListMarker));
      spheres_length = spheres_lengthT;
      for( uint32_t i = 0; i < spheres_length; i++){
      offset += this->st_spheres.deserialize(inbuffer + offset);
        memcpy( &(this->spheres[i]), &(this->st_spheres), sizeof(foxglove_msgs::SphereListMarker));
      }
      uint32_t cones_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      cones_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      cones_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      cones_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->cones_length);
      if(cones_lengthT > cones_length)
        this->cones = (foxglove_msgs::ConeListMarker*)realloc(this->cones, cones_lengthT * sizeof(foxglove_msgs::ConeListMarker));
      cones_length = cones_lengthT;
      for( uint32_t i = 0; i < cones_length; i++){
      offset += this->st_cones.deserialize(inbuffer + offset);
        memcpy( &(this->cones[i]), &(this->st_cones), sizeof(foxglove_msgs::ConeListMarker));
      }
      uint32_t lines_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      lines_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      lines_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      lines_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->lines_length);
      if(lines_lengthT > lines_length)
        this->lines = (foxglove_msgs::LineMarker*)realloc(this->lines, lines_lengthT * sizeof(foxglove_msgs::LineMarker));
      lines_length = lines_lengthT;
      for( uint32_t i = 0; i < lines_length; i++){
      offset += this->st_lines.deserialize(inbuffer + offset);
        memcpy( &(this->lines[i]), &(this->st_lines), sizeof(foxglove_msgs::LineMarker));
      }
      uint32_t triangles_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      triangles_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      triangles_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      triangles_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->triangles_length);
      if(triangles_lengthT > triangles_length)
        this->triangles = (foxglove_msgs::TriangleListMarker*)realloc(this->triangles, triangles_lengthT * sizeof(foxglove_msgs::TriangleListMarker));
      triangles_length = triangles_lengthT;
      for( uint32_t i = 0; i < triangles_length; i++){
      offset += this->st_triangles.deserialize(inbuffer + offset);
        memcpy( &(this->triangles[i]), &(this->st_triangles), sizeof(foxglove_msgs::TriangleListMarker));
      }
      uint32_t texts_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      texts_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      texts_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      texts_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->texts_length);
      if(texts_lengthT > texts_length)
        this->texts = (foxglove_msgs::TextMarker*)realloc(this->texts, texts_lengthT * sizeof(foxglove_msgs::TextMarker));
      texts_length = texts_lengthT;
      for( uint32_t i = 0; i < texts_length; i++){
      offset += this->st_texts.deserialize(inbuffer + offset);
        memcpy( &(this->texts[i]), &(this->st_texts), sizeof(foxglove_msgs::TextMarker));
      }
      uint32_t models_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      models_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      models_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      models_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->models_length);
      if(models_lengthT > models_length)
        this->models = (foxglove_msgs::ModelMarker*)realloc(this->models, models_lengthT * sizeof(foxglove_msgs::ModelMarker));
      models_length = models_lengthT;
      for( uint32_t i = 0; i < models_length; i++){
      offset += this->st_models.deserialize(inbuffer + offset);
        memcpy( &(this->models[i]), &(this->st_models), sizeof(foxglove_msgs::ModelMarker));
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/Markers"; };
    virtual const char * getMD5() override { return "7adad93502db1b37c29f6a3eafcc7dda"; };

  };

}
#endif
