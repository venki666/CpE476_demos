#ifndef _ROS_foxglove_msgs_PointCloud_h
#define _ROS_foxglove_msgs_PointCloud_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "ros/time.h"
#include "geometry_msgs/Pose.h"
#include "foxglove_msgs/PackedElementField.h"

namespace foxglove_msgs
{

  class PointCloud : public ros::Msg
  {
    public:
      typedef ros::Time _timestamp_type;
      _timestamp_type timestamp;
      typedef const char* _frame_id_type;
      _frame_id_type frame_id;
      typedef geometry_msgs::Pose _pose_type;
      _pose_type pose;
      typedef uint32_t _point_stride_type;
      _point_stride_type point_stride;
      uint32_t fields_length;
      typedef foxglove_msgs::PackedElementField _fields_type;
      _fields_type st_fields;
      _fields_type * fields;
      uint32_t data_length;
      typedef uint8_t _data_type;
      _data_type st_data;
      _data_type * data;

    PointCloud():
      timestamp(),
      frame_id(""),
      pose(),
      point_stride(0),
      fields_length(0), st_fields(), fields(nullptr),
      data_length(0), st_data(), data(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->timestamp.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.sec);
      *(outbuffer + offset + 0) = (this->timestamp.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id = strlen(this->frame_id);
      varToArr(outbuffer + offset, length_frame_id);
      offset += 4;
      memcpy(outbuffer + offset, this->frame_id, length_frame_id);
      offset += length_frame_id;
      offset += this->pose.serialize(outbuffer + offset);
      *(outbuffer + offset + 0) = (this->point_stride >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->point_stride >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->point_stride >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->point_stride >> (8 * 3)) & 0xFF;
      offset += sizeof(this->point_stride);
      *(outbuffer + offset + 0) = (this->fields_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->fields_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->fields_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->fields_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->fields_length);
      for( uint32_t i = 0; i < fields_length; i++){
      offset += this->fields[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->data_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->data_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->data_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->data_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->data_length);
      for( uint32_t i = 0; i < data_length; i++){
      *(outbuffer + offset + 0) = (this->data[i] >> (8 * 0)) & 0xFF;
      offset += sizeof(this->data[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->timestamp.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.sec);
      this->timestamp.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id;
      arrToVar(length_frame_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_frame_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_frame_id-1]=0;
      this->frame_id = (char *)(inbuffer + offset-1);
      offset += length_frame_id;
      offset += this->pose.deserialize(inbuffer + offset);
      this->point_stride =  ((uint32_t) (*(inbuffer + offset)));
      this->point_stride |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->point_stride |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->point_stride |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->point_stride);
      uint32_t fields_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      fields_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      fields_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      fields_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->fields_length);
      if(fields_lengthT > fields_length)
        this->fields = (foxglove_msgs::PackedElementField*)realloc(this->fields, fields_lengthT * sizeof(foxglove_msgs::PackedElementField));
      fields_length = fields_lengthT;
      for( uint32_t i = 0; i < fields_length; i++){
      offset += this->st_fields.deserialize(inbuffer + offset);
        memcpy( &(this->fields[i]), &(this->st_fields), sizeof(foxglove_msgs::PackedElementField));
      }
      uint32_t data_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      data_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      data_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      data_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->data_length);
      if(data_lengthT > data_length)
        this->data = (uint8_t*)realloc(this->data, data_lengthT * sizeof(uint8_t));
      data_length = data_lengthT;
      for( uint32_t i = 0; i < data_length; i++){
      this->st_data =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->st_data);
        memcpy( &(this->data[i]), &(this->st_data), sizeof(uint8_t));
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/PointCloud"; };
    virtual const char * getMD5() override { return "46355bb42c332657eb232925c4a8f134"; };

  };

}
#endif
