#ifndef _ROS_foxglove_msgs_ArrowMarker_h
#define _ROS_foxglove_msgs_ArrowMarker_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "geometry_msgs/Pose.h"
#include "foxglove_msgs/Color.h"

namespace foxglove_msgs
{

  class ArrowMarker : public ros::Msg
  {
    public:
      typedef geometry_msgs::Pose _pose_type;
      _pose_type pose;
      typedef double _length_type;
      _length_type length;
      typedef double _shaft_diameter_type;
      _shaft_diameter_type shaft_diameter;
      typedef double _head_diameter_type;
      _head_diameter_type head_diameter;
      typedef double _head_length_type;
      _head_length_type head_length;
      typedef foxglove_msgs::Color _color_type;
      _color_type color;

    ArrowMarker():
      pose(),
      length(0),
      shaft_diameter(0),
      head_diameter(0),
      head_length(0),
      color()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += this->pose.serialize(outbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_length;
      u_length.real = this->length;
      *(outbuffer + offset + 0) = (u_length.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_length.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_length.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_length.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_length.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_length.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_length.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_length.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->length);
      union {
        double real;
        uint64_t base;
      } u_shaft_diameter;
      u_shaft_diameter.real = this->shaft_diameter;
      *(outbuffer + offset + 0) = (u_shaft_diameter.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_shaft_diameter.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_shaft_diameter.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_shaft_diameter.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_shaft_diameter.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_shaft_diameter.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_shaft_diameter.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_shaft_diameter.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->shaft_diameter);
      union {
        double real;
        uint64_t base;
      } u_head_diameter;
      u_head_diameter.real = this->head_diameter;
      *(outbuffer + offset + 0) = (u_head_diameter.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_head_diameter.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_head_diameter.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_head_diameter.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_head_diameter.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_head_diameter.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_head_diameter.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_head_diameter.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->head_diameter);
      union {
        double real;
        uint64_t base;
      } u_head_length;
      u_head_length.real = this->head_length;
      *(outbuffer + offset + 0) = (u_head_length.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_head_length.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_head_length.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_head_length.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_head_length.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_head_length.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_head_length.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_head_length.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->head_length);
      offset += this->color.serialize(outbuffer + offset);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += this->pose.deserialize(inbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_length;
      u_length.base = 0;
      u_length.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_length.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_length.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_length.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_length.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_length.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_length.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_length.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->length = u_length.real;
      offset += sizeof(this->length);
      union {
        double real;
        uint64_t base;
      } u_shaft_diameter;
      u_shaft_diameter.base = 0;
      u_shaft_diameter.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_shaft_diameter.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_shaft_diameter.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_shaft_diameter.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_shaft_diameter.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_shaft_diameter.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_shaft_diameter.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_shaft_diameter.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->shaft_diameter = u_shaft_diameter.real;
      offset += sizeof(this->shaft_diameter);
      union {
        double real;
        uint64_t base;
      } u_head_diameter;
      u_head_diameter.base = 0;
      u_head_diameter.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_head_diameter.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_head_diameter.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_head_diameter.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_head_diameter.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_head_diameter.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_head_diameter.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_head_diameter.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->head_diameter = u_head_diameter.real;
      offset += sizeof(this->head_diameter);
      union {
        double real;
        uint64_t base;
      } u_head_length;
      u_head_length.base = 0;
      u_head_length.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_head_length.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_head_length.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_head_length.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_head_length.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_head_length.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_head_length.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_head_length.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->head_length = u_head_length.real;
      offset += sizeof(this->head_length);
      offset += this->color.deserialize(inbuffer + offset);
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/ArrowMarker"; };
    virtual const char * getMD5() override { return "c36d6b56f540801b30bba0c2c010f78e"; };

  };

}
#endif
