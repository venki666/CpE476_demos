#ifndef _ROS_foxglove_msgs_SceneEntities_h
#define _ROS_foxglove_msgs_SceneEntities_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "foxglove_msgs/SceneEntityDeletion.h"
#include "foxglove_msgs/SceneEntity.h"

namespace foxglove_msgs
{

  class SceneEntities : public ros::Msg
  {
    public:
      uint32_t deletions_length;
      typedef foxglove_msgs::SceneEntityDeletion _deletions_type;
      _deletions_type st_deletions;
      _deletions_type * deletions;
      uint32_t entities_length;
      typedef foxglove_msgs::SceneEntity _entities_type;
      _entities_type st_entities;
      _entities_type * entities;

    SceneEntities():
      deletions_length(0), st_deletions(), deletions(nullptr),
      entities_length(0), st_entities(), entities(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->deletions_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->deletions_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->deletions_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->deletions_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->deletions_length);
      for( uint32_t i = 0; i < deletions_length; i++){
      offset += this->deletions[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->entities_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->entities_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->entities_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->entities_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->entities_length);
      for( uint32_t i = 0; i < entities_length; i++){
      offset += this->entities[i].serialize(outbuffer + offset);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      uint32_t deletions_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      deletions_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      deletions_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      deletions_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->deletions_length);
      if(deletions_lengthT > deletions_length)
        this->deletions = (foxglove_msgs::SceneEntityDeletion*)realloc(this->deletions, deletions_lengthT * sizeof(foxglove_msgs::SceneEntityDeletion));
      deletions_length = deletions_lengthT;
      for( uint32_t i = 0; i < deletions_length; i++){
      offset += this->st_deletions.deserialize(inbuffer + offset);
        memcpy( &(this->deletions[i]), &(this->st_deletions), sizeof(foxglove_msgs::SceneEntityDeletion));
      }
      uint32_t entities_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      entities_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      entities_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      entities_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->entities_length);
      if(entities_lengthT > entities_length)
        this->entities = (foxglove_msgs::SceneEntity*)realloc(this->entities, entities_lengthT * sizeof(foxglove_msgs::SceneEntity));
      entities_length = entities_lengthT;
      for( uint32_t i = 0; i < entities_length; i++){
      offset += this->st_entities.deserialize(inbuffer + offset);
        memcpy( &(this->entities[i]), &(this->st_entities), sizeof(foxglove_msgs::SceneEntity));
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/SceneEntities"; };
    virtual const char * getMD5() override { return "59bc58a3679e8fc3874b14b39276e03a"; };

  };

}
#endif
