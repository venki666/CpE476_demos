#ifndef _ROS_SERVICE_example_server_msg_h
#define _ROS_SERVICE_example_server_msg_h
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace example_ros_service
{

static const char EXAMPLE_SERVER_MSG[] = "example_ros_service/example_server_msg";

  class example_server_msgRequest : public ros::Msg
  {
    public:
      typedef const char* _name_type;
      _name_type name;

    example_server_msgRequest():
      name("")
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      uint32_t length_name = strlen(this->name);
      varToArr(outbuffer + offset, length_name);
      offset += 4;
      memcpy(outbuffer + offset, this->name, length_name);
      offset += length_name;
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      uint32_t length_name;
      arrToVar(length_name, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_name; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_name-1]=0;
      this->name = (char *)(inbuffer + offset-1);
      offset += length_name;
     return offset;
    }

    virtual const char * getType() override { return EXAMPLE_SERVER_MSG; };
    virtual const char * getMD5() override { return "c1f3d28f1b044c871e6eff2e9fc3c667"; };

  };

  class example_server_msgResponse : public ros::Msg
  {
    public:
      typedef bool _on_the_list_type;
      _on_the_list_type on_the_list;
      typedef bool _good_class_type;
      _good_class_type good_class;
      typedef int32_t _numstuds_type;
      _numstuds_type numstuds;
      typedef const char* _nickname_type;
      _nickname_type nickname;

    example_server_msgResponse():
      on_the_list(0),
      good_class(0),
      numstuds(0),
      nickname("")
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_on_the_list;
      u_on_the_list.real = this->on_the_list;
      *(outbuffer + offset + 0) = (u_on_the_list.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->on_the_list);
      union {
        bool real;
        uint8_t base;
      } u_good_class;
      u_good_class.real = this->good_class;
      *(outbuffer + offset + 0) = (u_good_class.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->good_class);
      union {
        int32_t real;
        uint32_t base;
      } u_numstuds;
      u_numstuds.real = this->numstuds;
      *(outbuffer + offset + 0) = (u_numstuds.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_numstuds.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_numstuds.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_numstuds.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->numstuds);
      uint32_t length_nickname = strlen(this->nickname);
      varToArr(outbuffer + offset, length_nickname);
      offset += 4;
      memcpy(outbuffer + offset, this->nickname, length_nickname);
      offset += length_nickname;
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_on_the_list;
      u_on_the_list.base = 0;
      u_on_the_list.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->on_the_list = u_on_the_list.real;
      offset += sizeof(this->on_the_list);
      union {
        bool real;
        uint8_t base;
      } u_good_class;
      u_good_class.base = 0;
      u_good_class.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->good_class = u_good_class.real;
      offset += sizeof(this->good_class);
      union {
        int32_t real;
        uint32_t base;
      } u_numstuds;
      u_numstuds.base = 0;
      u_numstuds.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_numstuds.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_numstuds.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_numstuds.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->numstuds = u_numstuds.real;
      offset += sizeof(this->numstuds);
      uint32_t length_nickname;
      arrToVar(length_nickname, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_nickname; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_nickname-1]=0;
      this->nickname = (char *)(inbuffer + offset-1);
      offset += length_nickname;
     return offset;
    }

    virtual const char * getType() override { return EXAMPLE_SERVER_MSG; };
    virtual const char * getMD5() override { return "8e44a81ded0eb57680b82754b4906793"; };

  };

  class example_server_msg {
    public:
    typedef example_server_msgRequest Request;
    typedef example_server_msgResponse Response;
  };

}
#endif
