#ifndef _ROS_custom_msgs_VecOfDoubles_h
#define _ROS_custom_msgs_VecOfDoubles_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace custom_msgs
{

  class VecOfDoubles : public ros::Msg
  {
    public:
      uint32_t dbl_vec_length;
      typedef double _dbl_vec_type;
      _dbl_vec_type st_dbl_vec;
      _dbl_vec_type * dbl_vec;

    VecOfDoubles():
      dbl_vec_length(0), st_dbl_vec(), dbl_vec(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->dbl_vec_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->dbl_vec_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->dbl_vec_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->dbl_vec_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->dbl_vec_length);
      for( uint32_t i = 0; i < dbl_vec_length; i++){
      union {
        double real;
        uint64_t base;
      } u_dbl_veci;
      u_dbl_veci.real = this->dbl_vec[i];
      *(outbuffer + offset + 0) = (u_dbl_veci.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_dbl_veci.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_dbl_veci.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_dbl_veci.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_dbl_veci.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_dbl_veci.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_dbl_veci.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_dbl_veci.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->dbl_vec[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      uint32_t dbl_vec_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      dbl_vec_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      dbl_vec_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      dbl_vec_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->dbl_vec_length);
      if(dbl_vec_lengthT > dbl_vec_length)
        this->dbl_vec = (double*)realloc(this->dbl_vec, dbl_vec_lengthT * sizeof(double));
      dbl_vec_length = dbl_vec_lengthT;
      for( uint32_t i = 0; i < dbl_vec_length; i++){
      union {
        double real;
        uint64_t base;
      } u_st_dbl_vec;
      u_st_dbl_vec.base = 0;
      u_st_dbl_vec.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_dbl_vec.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_dbl_vec.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_dbl_vec.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_st_dbl_vec.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_st_dbl_vec.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_st_dbl_vec.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_st_dbl_vec.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->st_dbl_vec = u_st_dbl_vec.real;
      offset += sizeof(this->st_dbl_vec);
        memcpy( &(this->dbl_vec[i]), &(this->st_dbl_vec), sizeof(double));
      }
     return offset;
    }

    virtual const char * getType() override { return "custom_msgs/VecOfDoubles"; };
    virtual const char * getMD5() override { return "e9ddfb3c374c7aa1ad63fcedb2691ab2"; };

  };

}
#endif
