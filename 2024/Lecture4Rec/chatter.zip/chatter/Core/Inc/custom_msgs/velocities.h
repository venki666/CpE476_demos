#ifndef _ROS_custom_msgs_velocities_h
#define _ROS_custom_msgs_velocities_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace custom_msgs
{

  class velocities : public ros::Msg
  {
    public:
      typedef float _leftvel_type;
      _leftvel_type leftvel;
      typedef float _rightvel_type;
      _rightvel_type rightvel;

    velocities():
      leftvel(0),
      rightvel(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_leftvel;
      u_leftvel.real = this->leftvel;
      *(outbuffer + offset + 0) = (u_leftvel.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_leftvel.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_leftvel.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_leftvel.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->leftvel);
      union {
        float real;
        uint32_t base;
      } u_rightvel;
      u_rightvel.real = this->rightvel;
      *(outbuffer + offset + 0) = (u_rightvel.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_rightvel.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_rightvel.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_rightvel.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->rightvel);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_leftvel;
      u_leftvel.base = 0;
      u_leftvel.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_leftvel.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_leftvel.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_leftvel.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->leftvel = u_leftvel.real;
      offset += sizeof(this->leftvel);
      union {
        float real;
        uint32_t base;
      } u_rightvel;
      u_rightvel.base = 0;
      u_rightvel.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_rightvel.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_rightvel.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_rightvel.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->rightvel = u_rightvel.real;
      offset += sizeof(this->rightvel);
     return offset;
    }

    virtual const char * getType() override { return "custom_msgs/velocities"; };
    virtual const char * getMD5() override { return "c63075cf113c8745ac71856e35987b29"; };

  };

}
#endif
