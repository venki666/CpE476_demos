#include "app_ackerman.h"
#include "app_motion.h"
#include "app_flash.h"
#include "app_math.h"
#include "app.h"


#include "bsp_pwmServo.h"
#include "bsp_usart.h"


static int speed_L_setup = 0;
static int speed_R_setup = 0;


int akm_speed_fb = 0;
int akm_servo_angle = 0;

float akm_speed_angle = 0;
float akm_angle = 0;

uint16_t g_ackerman_default_angle = AKM_ANGLE_INIT;

// 控制阿克曼舵机转动角度，左负右正。angle=±45
void Ackerman_Steering(int16_t angle)
{
    akm_servo_angle = angle;
    PwmServo_Set_Angle(AKM_ANGLE_ID, Ackerman_Get_Default_Angle() + angle);
}

// 获取阿克曼前轮舵机转向角度
int16_t Ackerman_Get_Steer_Angle(void)
{
    return -akm_servo_angle;
}

uint16_t Ackerman_Get_Default_Angle(void)
{
    return g_ackerman_default_angle;
}

void Ackerman_Set_Default_Angle(uint16_t angle, uint8_t forever)
{
    if (angle > 180) return;
    g_ackerman_default_angle = angle;
    PwmServo_Set_Angle(AKM_ANGLE_ID, g_ackerman_default_angle);
    if(forever)
    {
        Flash_Set_AKM_Angle(g_ackerman_default_angle);
    }
}


// X轴速度(前正后负：±1000)，Y轴舵机角度(左正右负:±45)，Z轴速度(角速度，左正右负：±3000)
void Ackerman_Ctrl(int16_t V_x, int16_t V_y, int16_t V_z, uint8_t adjust)
{
    akm_speed_fb = V_x;
    if (V_y != 0xff) 
        akm_servo_angle = Math_Limit_int(-V_y, -AKM_ANGLE_LIMIT, AKM_ANGLE_LIMIT);
    akm_angle = akm_servo_angle * AtR;
    if (V_x == 0)
    {
        Motion_Stop(STOP_BRAKE);
        Ackerman_Steering(akm_servo_angle);
        DEBUG("akm stop steer:%d\n", akm_servo_angle);
        akm_speed_angle = 0;
        akm_angle = 0;
        return;
    }
    if (akm_servo_angle == 0)
    {
        akm_speed_angle = -V_z/1000.0f;
        akm_angle = atanf(akm_speed_angle*AKM_LENGTH/akm_speed_fb);
        akm_servo_angle = Math_Limit_int(akm_angle*RtA, -AKM_ANGLE_LIMIT, AKM_ANGLE_LIMIT);
        Ackerman_Steering(akm_servo_angle);
    }
    else
    {
        Ackerman_Steering(akm_servo_angle);
    }
    speed_L_setup = akm_speed_fb*(1+AKM_WIDTH*tan(akm_angle)/2/AKM_LENGTH);
    speed_R_setup = akm_speed_fb*(1-AKM_WIDTH*tan(akm_angle)/2/AKM_LENGTH);
    speed_L_setup = Math_Limit_int(speed_L_setup, -AKM_MOTOR_MAX_SPEED, AKM_MOTOR_MAX_SPEED);
    speed_R_setup = Math_Limit_int(speed_R_setup, -AKM_MOTOR_MAX_SPEED, AKM_MOTOR_MAX_SPEED);
    
    Motion_Set_Speed(0, speed_L_setup, 0, speed_R_setup);
}

// 控制阿克曼小车的运动状态
void Ackerman_State(uint8_t state, uint16_t speed, uint8_t adjust)
{
    switch (state)
    {
    case MOTION_STOP:
        if (adjust)
        {
            Ackerman_Steering(0);
        }
        Motion_Stop(speed==0?STOP_FREE:STOP_BRAKE);
        break;
    case MOTION_RUN:
        Ackerman_Ctrl(speed, 0xff, 0, adjust);
        break;
    case MOTION_BACK:
        Ackerman_Ctrl(-speed, 0xff, 0, adjust);
        break;
    case MOTION_LEFT:
        Ackerman_Ctrl(speed, 25, 0, adjust);
        break;
    case MOTION_RIGHT:
        Ackerman_Ctrl(speed, -25, 0, adjust);
        break;
    case MOTION_SPIN_LEFT:
        Ackerman_Ctrl(speed, 45, 0, adjust);
        break;
    case MOTION_SPIN_RIGHT:
        Ackerman_Ctrl(speed, -45, 0, adjust);
        break;
    case MOTION_BRAKE:
        Ackerman_Steering(0);
        Motion_Stop(STOP_BRAKE);
        break;
    default:
        break;
    }
}


void Ackerman_Send_Default_Angle(void)
{
    #define LEN        7
	uint8_t data_buffer[LEN] = {0};
	uint8_t i, checknum = 0;
	data_buffer[0] = PTO_HEAD;
	data_buffer[1] = PTO_DEVICE_ID-1;
	data_buffer[2] = LEN-2; // 数量
	data_buffer[3] = FUNC_AKM_DEF_ANGLE; // 功能位
	data_buffer[4] = AKM_ANGLE_ID+1;
	data_buffer[5] = g_ackerman_default_angle & 0xff;

	for (i = 2; i < LEN-1; i++)
	{
		checknum += data_buffer[i];
	}
	data_buffer[LEN-1] = checknum;
	USART1_Send_ArrayU8(data_buffer, sizeof(data_buffer));
}
